package src;
import java.util.Collections;
import java.util.ArrayList;
import java.util.Comparator;

public class Seq1D<T extends Comparable<T>> {
   protected ArrayList<Double> s;
   protected MeanCalculator meanCalculator;

   public Seq1D(ArrayList<Double> x, MeanCalculator m) {
	   if (x.size()==0) {
         throw new IllegalArgumentException("Argument is not contained in the sequence");
      }
      s = x;
      meanCalculator = m;
   }

   public void setMeanCalculator(MeanCalculator m) {
      meanCalculator = m;
   }    

   public double mean() {
      return meanCalculator.meanCalc(s);
   }

   
}
