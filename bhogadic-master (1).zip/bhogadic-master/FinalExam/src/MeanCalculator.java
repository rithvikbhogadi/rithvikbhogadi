package src;
import java.util.ArrayList;

public interface MeanCalculator{
    public double meanCalc(ArrayList<Double> L);
}
