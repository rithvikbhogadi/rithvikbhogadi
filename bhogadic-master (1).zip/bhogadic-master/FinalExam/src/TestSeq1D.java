package src;

import org.junit.*;
import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.Arrays;

public class TestSeq1D
{

   @Before
   public void setUp()
   {

   }

   @After
   public void tearDown()
   {

   }

   @Test
   public void testTrue()
   {
      assertEquals(1.0, 1.0, 1e-6);
   }

}
