package src;
import java.util.Collections;
import java.util.ArrayList;

public class HarmonicMean implements MeanCalculator {

    public double meanCalc(ArrayList<Double> L) {
        double sum = 0.0;
        for (int i = 0; i < L.size(); i++)
        {
           sum = sum + 1.0/L.get(i);
        }
        return L.size()/sum;
    }
}
