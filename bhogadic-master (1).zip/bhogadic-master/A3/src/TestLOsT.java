/**
 * Author: 
 * Revised: 
 * 
 * Description: 
 */

package src;

import org.junit.*;
import static org.junit.Assert.*;

public class TestLOsT
{

    @Test
    public void testBlank()
    {
        testing3 = new AttributeT("oasas", IndicatorT.math());
        assertTrue(testing3.getName == "oasas");

    }

    public void testBlank()
    {
        testing4 = new AttributeT(LOsT.math());
        assertTrue(testing4.getName == true);

    }


}
