/**
 * Author:
 * Revised:
 * 
 * Description:
 */

package src;

import org.junit.*;
import static org.junit.Assert.*;

public class TestProgramT
{
	
	@Test
    public void testBlank()
    {
        assertTrue(true);
    }

}
