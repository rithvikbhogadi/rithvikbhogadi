## @file SetOfInt.py
#  @author Rithvik Bhogadi
#  @brief Set of integers
#  @date 03/04/2021

class SetOfInt():

    def __init__(self,xs,s):
        s = set()
        for i in (xs):
            s.add(i)
        self.s = s
    
    def is_member(self,x):
        for i in (self.s):
            if (x == i):
                return True
    
    def to_seq(self):
        return list(self.s)
    
    def union(self,t):
        return
    
    def diff(self,t):
        return 
    
    def size(self):
        return len(self.s)
    
    def empty(self):
        for i in (self.s):
            if (i == None):
                return True

    def equals(self,t):
        for i in (self.s):
            if (t.to_seq() == i):
                return True

        
            
    

