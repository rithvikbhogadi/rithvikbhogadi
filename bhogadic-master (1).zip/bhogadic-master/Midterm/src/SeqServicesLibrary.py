## @file SeqServicesLibrary.py
#  @author Rithvik Bhogadi
#  @brief Library module that provides functions for working with sequences
#  @details This library assumes that all functions will be provided with arguments of the expected types
#  @date 03/04/2021


def max_val(self,s):
    m = self.s[0]
    if (len(self.s) == 0):
        return ValueError
    for x in (self.s):
        if (abs(x) >= m):
            m = abs(x)
    return m

     
def count(self,t,s):
    counter = 0 
    if (len(self.s) == 0):
        return ValueError
    for x in (self.s):
        if (x == self.t):
            counter = counter + 1
    return counter

def spices(self,s):
    list_1 = []
    if (len(self.s) == 0):
        return ValueError
    for x in (self.s):
        if (x <= 0):
            list_1.append("nutmeg")
        else:
            list_1.append("ginger")
    return list_1

def new_max_val(self,s,f):
    list_2 = self.s
    if (len(self.s) == 0):
        return ValueError
    for x in (list_2):
        self.f(x)
    return list_2.max_val()
    
    

    
    



    


